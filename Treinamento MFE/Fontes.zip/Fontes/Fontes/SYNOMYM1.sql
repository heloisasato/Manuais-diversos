set current sqlid='DB2ME';
create synonym TBPJFIL9 for db2cas.TBPJFIL9;
